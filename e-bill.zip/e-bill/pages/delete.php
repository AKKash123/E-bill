<?php
session_start();
include'../includes/connection.php';
// Check if billid parameter is set and not empty
 if (isset($_GET['billid']) && !empty($_GET['billid'])) {
     // Sanitize the input to prevent any security issues
     $billid = htmlspecialchars($_GET['billid']);

    // Now you can use $billid in your PHP code
    //echo "The Invoice ID is: $billid"."Revised-invoice";
     		$sql = "DELETE FROM billbook WHERE bill_id= $billid";

			if (mysqli_query($db, $sql)) {
				header("Location:allbill.php");
			  $_SESSION['status']="Record deleted successfully";
			} else {
			 $_SESSION['status']= "Error deleting record: " . mysqli_error($db);
			}

     } 
     else {
              // Handle the case when billid is not provided in the URL
        echo "Bill ID is missing.";
      }
?>