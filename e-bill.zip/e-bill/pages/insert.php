<?php
session_start();
include'../includes/connection.php';
//All variables
//echo"hi";
$bill_id =$_POST['bill_id'];
$custname =$_POST['custname'];
//echo $custname;
$custcontact = $_POST['custcontact'];
$custaddress = $_POST['custaddress'];
$model = $_POST['model'];
$machineslno =$_POST['machineslno'];
$maxcap = $_POST['maxcap'];
$mincap = $_POST['mincap'];
$eisd = $_POST['eisd'];
$class = $_POST['class'];
$brand = $_POST['brand'];
$additional = $_POST['additional'];
$govfees = $_POST['govfees'];
$otherdetails = $_POST['otherdetails'];
$rate = $_POST['rate'];
$qty = $_POST['qty'];
$amount = $_POST['amount'];
$grandtotal=$_POST['grandtotal'];

//Array data

$newmodel = implode(',',$model);
$newmachineslno = implode(',',$machineslno);
$newmaxcap = implode(',',$maxcap);
$newmincap = implode(',',$mincap);
$neweisd = implode(',',$eisd);
$newclass = implode(',',$class);
$newbrand = implode(',',$brand);
$newadditional = implode(',',$additional);
$newgovfees = implode(',',$govfees);

//echo($newmodel);
if(empty($custname)||empty($custcontact)||empty($custaddress)||empty($grandtotal)){
	header("Location:index.php");
	$_SESSION['mystatus']= "Fill all the fields";
}
else{
	$sql = "INSERT INTO billbook(bill_id,custname,custaddress,custcontact,model,machineslno,maxcap,mincap,eisd,class,brand,additional,govfees,otherdetails,rate,qty,amount,grandtotal) VALUES('".$bill_id."','".$custname."','".$custaddress."','".$custcontact."','".$newmodel."','".$newmachineslno."','".$newmaxcap."','".$newmincap."','".$neweisd."','".$newclass."','".$newbrand."','".$newadditional."','".$newgovfees."','".$otherdetails."','".$rate."','".$qty."','".$amount."','".$grandtotal."')";

	//echo($sql);
	$query = mysqli_query($db,$sql);

	if($query)
	{
		header("Location:index.php");
		  $_SESSION['mystatus']= "Data has been saved";
		  
	}
	else{
		header("Location:index.php");
		$_SESSION['mystatus']= "Data has not saved!";
		
	}
}
?>