<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <script src="https://cdn.jsdelivr.net/npm/rich-text-editor-vj@3.0.6/js/froala_editor.min.js"></script>
<style type="text/css">
  .btn-c{
  background: linear-gradient(90deg, rgba(131, 58, 180, 1) 0%, rgba(202, 59, 99, 1) 12%, rgb(237 59 59) 18%, rgba(252, 176, 69, 1) 100%);
    border-radius: 19px;
    padding: 13px;
    cursor: pointer;
  }
  #regbtn:hover{
  background:rgb(237 85 59) 18%;
  }
</style>
<?php
include'../includes/connection.php';
include'../includes/sidebar.php';
?><?php 

                $query = 'SELECT id type FROM users 
                          WHERE id = '.$_SESSION['MEMBER_ID'].'';
                $result = mysqli_query($db, $query) or die (mysqli_error($db));
      
                while ($row = mysqli_fetch_assoc($result)) {
                          $Aa = $row['type'];
                   
if ($Aa=='User'){
           
             ?>    <script type="text/javascript">
                      //then it will be redirected
                      alert("Restricted Page! You will be redirected to POS");
                      window.location = "pos.php";
                  </script>
             <?php   }
                         
           
}

?>
<?php
 $n=6;
function randomNumber($n) {
 $characters = '0123456789';
 $randomString = '';
 for ($i = 0; $i < $n; $i++) {
  $index = rand(0, strlen($characters) - 1);
  $randomString .= $characters[$index];
 }
 return $randomString;
}
//echo randomNumber($n);
$billno =randomNumber($n);

?>

 <div class="row">

                <div class="col-lg-12">
                  <div class="card shadow mb-0">
                  <div class="card-header py-2">
                    <h4 class="m-1 text-lg text-primary"> <i class=" fas fa-solid fa-book"></i>Bill Book <p class="text-warning">Invoice_number:#<?php echo $billno;?></p></h4><div class="form-group col-lg-6" id="billref"><input type="hidden" value="<?php echo$billno;?>" id="bill_id" name="bill_id"></div>
                  </div>
                 

                        <!-- /.panel-heading -->
                        <div  id="Card"class="card-body">
                            <!-- Nav tabs -->
                            <ul  id ="mysection"class="nav nav-tabs">
                              <li class="nav-item col-lg-4">
                                <a class="nav-link" href="#customerinfo" data-toggle="collapse">Customer-information</a>
                              </li>
                              <li class="nav-item col-lg-4">
                                <a class="nav-link mycollapse1" href="#machine" data-toggle="mycollapse1"  >Machine-details</a>
                              </li>
                              <li class="nav-item col-lg-4">
                              <a class="nav-link mycollapse2" href="#other" data-toggle="mycollapse2" >Other-details</a>
                              </li>
                            </ul>

<br>
  <form role="form" method="post" id="billform"> 
  <div class="col-lg-12" id="customerinfo">
    <div class="form-group col-lg-12">
      <input type="hidden" value="<?php echo$billno;?>" id="bill_id" name="bill_id">
      <input type="hidden"  id="invoicedate" name="invoicedate">
              <input type="text" class="form-control required" placeholder="Customer Name" name="custname" id="custname" required>
    </div>
    <div class="form-group col-lg-12">
              <input type="tel" class="form-control required" placeholder="Customer contact" inputmode="numeric" name="custcontact" id="custcontact"required>
    </div>
     <div class="form-group col-lg-12">
              <input type="text" class="form-control required" placeholder="Customer address" name="custaddress"id="custaddress" required>
    </div>
  </div>
  <div class="col-lg-12" id="machine">
      <div class="form-group col-lg-12">
                <input type="text" class="form-control required" placeholder="Model" name="model[]" id="model" >
      </div>
      <div class="form-group col-lg-12">
                <input type="text" class="form-control required" placeholder="Machine serial number" name="machineslno[]"id="machineslno" required>
      </div>
          <div class="row">
             <div class="form-group col-lg-6">
                      <input type="text" class="form-control required" placeholder="Maximum Capacity" name="maxcap[]" id="maxcap" required>
            </div>
            <div class="form-group col-lg-6">
                      <input type="text" class="form-control required" placeholder="Minimum Capacity" name="mincap[]" id="mincap" required>
            </div>
        </div>
        <div class="row">
             <div class="form-group col-lg-6">
                      <input type="text" class="form-control required" placeholder="e=d" name="eisd[]" id="eisd[]" required>
            </div>
            <div class="form-group col-lg-6">
                      <input type="text" class="form-control required" placeholder="class" name="class[]" id="class" required>
            </div>
        </div>
          <div class="row">
               <div class="form-group col-lg-6">
                        <input type="text" class="form-control required" placeholder="Brand/Mfd." name="brand[]" id="brand" required>
              </div>
              <div class="form-group col-lg-6">
                        <input type="text" class="form-control" placeholder="Additional" name="additional[]" id="additional" >
              </div>
              <div class="form-group col-lg-6">
                <div class="input-group mb-3">
                      <div class="input-group-prepend">
                        <span class="input-group-text">₹</span>
                      </div>
                      <input type="number" class="form-control  govfeecal" placeholder="Govt.fees" name="govfees[]" id="govfees" min="0" required>
                      <div class="input-group-append">
                        <span class="input-group-text">.00</span>
                      </div>
                </div>
              </div>
          </div>
          <button type="button" class="btn btn-c text-white" id="addrow">Addmore+</button><br>
            <div class="form-group col-lg-12">
              <label for="vcno">Vc Number:</label>
                <input type="text" class="form-control required" placeholder="Remarks" name="remarks1" id="remarks1" >
            </div>
</div>
  </div>
  <div class="col-lg-12 newinput" id="machine"></div>
<div class="col-lg-12" id="other">
        <div class="form-group col-lg-12">
                <br><input type="text" class="form-control" placeholder="Other details" name="otherdetails" id="otherdetails">
      </div>
      <div class="row">
         <div class="form-group col-lg-6">
                   <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">₹</span>
                    </div>
                    <input type="number" class="form-control " placeholder="rate" name="rate" id="rate" min="0">
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                    </div>
              </div>
        </div>
      
        <div class="form-group col-lg-6">
                  <input type="number" class="form-control required" placeholder="Quantity" name="qty" id="qty"min="0" >
        </div>
        <div class="form-group col-lg-6">
              <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">₹</span>
                    </div>
                    <input type="number" class="form-control txtCal" placeholder="Amount" name="amount" id="amount" min="0">
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                    </div>
              </div>
                <hr>
              <h5 class=" alert bg-primary text-white detail">Cleaning/Re-calibration/Fixing revate stamping plug/Testing/Service/Reparing/Other Works</h5>
                <hr>
                <div class="form-group col-lg-12">
                <input type="text" class="form-control" placeholder="Enter the service name" name="otherworks" id="otherworks">
              </div>
                <div class="form-group col-lg-6">
                  <input type="number" class="form-control required qty1" placeholder="Quantity" name="qty1" id="qty1"min="0" >
                </div>
                <div class="form-group col-lg-6">
                   <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">₹</span>
                    </div>
                    <input type="number" class="form-control rate1" placeholder="Rate " name="rate1" id="rate1" min="0">
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                    </div>
              </div>
        </div>
       <!--  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">Total Amount :₹</span>
                    </div>&nbsp;&nbsp;
                    <span id="amt1"></span>&nbsp;&nbsp;
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                      
                    </div>
              </div> -->
        <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">₹</span>
                    </div>
                    <input type="number" class="form-control txtCal" placeholder="Amount" name="amount1" id="amount1" min="0">
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                    </div>
              </div>
              
              <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">Total govtfees: ₹</span>
                    </div>
                    <input type="number" class="form-control required txtCal" id="totalgovtfee" name="totalgovtfee" placeholder="Write the above  grand total govt.fees amount" min="0" >
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                      
                    </div>
              </div>
              <div class="input-group mb-3">
                   <!--  <div class="input-group-prepend">
                      <span class="input-group-text">Grand Total :₹</span>
                    </div>&nbsp;&nbsp;
                    <span id="grandtotal"></span>&nbsp;&nbsp;
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                      
                    </div> -->
                    <button class="btn-c text-white sm-3" id="gtotal">Get grand total</button>
              </div>
              <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">Grand Total :₹</span>
                    </div>
                    <input type="number" class="form-control required" id="grandtotal" name="grandtotal" placeholder="Write the above  grand total amount" min="0" >
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                      
                    </div>
              </div>
              <div class="form-group col-lg-12">
                  <label for="vcno">Remarks:</label><input type="text" class="form-control required" placeholder="Remarks" name="remarks2" id="remarks2" >
              </div>
              <!-- <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text">Total Govt.fees :₹</span>
                    </div>&nbsp;&nbsp;
                    <span id="govtotal"></span>&nbsp;&nbsp;
                    <div class="input-group-append">
                      <span class="input-group-text">.00</span>
                      
                    </div>
              </div> -->
              
            </div>
        </div>
</div>

</div>

<br><button class="btn btn-c text-white" id="regbtn" >Save</button><br>
<br><a href="billview.php?=<?php echo$billno;?>" class="btn btn-c text-white" id="view" >View</a><br>
</form>

    <script type="text/javascript">
    $(document).ready(function(){
          //$("#billref").hide();
        $('#view').hide();
        //$("#mysection").hide();
        $("#heatbtn").hide();
        //$("#Card").hide();
          $("#machine").hide();
          $("#other").hide();
          $(".mycollapse1").click(function(){
            $("#machine").toggle();
          });
          $(".mycollapse2").click(function(){
            $("#other").toggle();
          });
            
          // $("#heatbtn").click(function(e){
          //   e.preventDefault();
          //   $("#mysection").show();
          //   $("#Card").show();
          // });
          $("#addrow").click(function () {
            //console.log("hi");
             newRowAdd =
                '<div id="row"> ' +
                '<br><button class="btn btn-danger" id="DeleteRow" type="button">' +
                '<i class="bi bi-trash"></i> Delete</button><br>' +
                '<div class="form-group col-lg-12">'+'<input type="text" class="form-control" placeholder="Model" name="model[]" id="model" ><br>'+'<input type="text" class="form-control" placeholder="Machine serial number" name="machineslno[]"id="machineslno" ><br>'+
    
          '<div class="row"><div class="form-group col-lg-6">'+
                      '<input type="text" class="form-control" placeholder="Maximum Capacity" name="maxcap[]" id="maxcap" ></div>'+
            '<div class="form-group col-lg-6"><input type="text" class="form-control" placeholder="Minimum Capacity" name="mincap[]" id="mincap"></div></div>'+
        '<div class="row"><div class="form-group col-lg-6">'+
                      '<input type="text" class="form-control" placeholder="e=d" name="eisd[]" id="eisd"></div>'+
            '<div class="form-group col-lg-6"><input type="text" class="form-control" placeholder="class" name="class[]" id="class"></div></div>'+
          '<div class="row"><div class="form-group col-lg-6">'+
                        '<input type="text" class="form-control" placeholder="Brand/Mfd." name="brand[]" id="brand"></div>'+
              '<div class="form-group col-lg-6"><input type="text" class="form-control" placeholder="Additional" name="additional[]" id="additional" ></div>'+
              '<div class="form-group col-lg-6">'+
                '<div class="input-group mb-3">'+
                      '<div class="input-group-prepend"><span class="input-group-text">₹</span></div>'+
                      '<input type="number" min="0" class="form-control  govfeecal" placeholder="Govt.fees" name="govfees[]" id="govfees">'+
                      '<div class="input-group-append">'
                        '<span class="input-group-text">.00</span></div></div></div> </div></div>';

                
          $('#machine').append(newRowAdd);
          });
           $("body").on("click", "#DeleteRow", function () {
            $(this).parents("#row").remove();
            //console.log("hi");
        });
          //  $("body").on('input', '.txtCal', function () {
          //         var calculated_total_sum = 0;
          //                $("body .txtCal").each(function () {
          //        var get_textbox_value = $(this).val();
          //        if ($.isNumeric(get_textbox_value)) {
          //           calculated_total_sum += parseFloat(get_textbox_value);
          //           }                  
          //         });
          //                //console.log(calculated_total_sum);
          //                $("#grandtotal").html(calculated_total_sum);
          //       //$("#grandtotal").val(calculated_total_sum).val();
          // });

            $(document).ready(function(){
              $('#gtotal').click(function(e){
                  e.preventDefault();
                  //console.log("gtotal");
                  let amount = $('#amount').val();
                  let amount1 = $('#amount1').val();
                  let totalgovtfee = $('#totalgovtfee').val();

                  // console.log(amount);
                  //  console.log(amount1);
                  //   console.log(totalgovtfee);
                  let grandtotal = parseFloat(amount)+parseFloat(amount1)+parseFloat(totalgovtfee);
                  //console.log(grandtotal);
                  $("#grandtotal").val(grandtotal).val();

              });
               
            });
            
           $("body").on('input', '.govfeecal', function () {
                  var calculated_total_sums = 0;
                         $("body .govfeecal").each(function () {
                 var get_textbox_value1 = $(this).val();
                 if ($.isNumeric(get_textbox_value1)) {
                    calculated_total_sums += parseFloat(get_textbox_value1);
                    }                  
                  });
                         //console.log(calculated_total_sum);
                $("#totalgovtfee").val(calculated_total_sums).val();
          });

           $(document).ready(function(){
                $('#rate').keyup(calculates);
                $('#qty').keyup(calculates);
            });
            function calculates(e)
            {
                $('#amount').val($('#rate').val() * $('#qty').val());
            }
           $(document).ready(function(){
                $('#rate1').keyup(calculate);
                $('#qty1').keyup(calculate);
            });
            function calculate(e)
            {
                $('#amount1').val($('#rate1').val() * $('#qty1').val());
            }
           
         //Form method
           $("#billform").submit(function(){

                 //e.preventDefault();
                var frmdata = $("#billform").serialize();
                //console.log(frmdata);
                  
                $.ajax({
                   url:"insert.php",
                   method:"POST",
                   data:frmdata,
                   success: function(data) {
                    var invoiceid = $("#bill_id").val();
                    window.location.href="preview.php?bill_id="+invoiceid;
                      // if(data==1){
                      //   alert("Data Saved");
                      //   //document.getElementById("billform").reset();
                      // }
                      //   else if(data==0){

                      //     alert("Sorry data has not saved");
                      //   }   
                      //      //document.getElementById("heatbtn").style.display='block';
                      //     //document.getElementById("billform").reset();
                      //   }
                  }
                });
        
        });

                             
        

      });

      

    </script>
    <script type="text/javascript">
      //copy function
      //  function PreviewFunction(){
      //   var Text = document.getElementById("bilno");
      //   // Select the text field
      //   // copyText.select();
      //   // //copyText.setSelectionRange(0, 99999); // For mobile devices

      //   // // Copy the text inside the text field
      //   // navigator.clipboard.writeText(copyText.value);

      //   // // Alert the copied text
      //   // alert(" Invoice id has been Copied: "   + copyText.value+     "Please keep the id to search your bill from all bill section");
      //   window.location.href="billview.php=";

      // }
    </script>
   <!--  <script type="text/javascript">
      function Open(){
        document.getElementById("billref").style.display="block";
      }
    </script> -->
<footer>
<?php
include'../includes/footer.php';
?>
</footer>