<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<style type="text/css">
  body {
  -webkit-print-color-adjust: exact !important;
}
.btn-c{
  background: linear-gradient(90deg, rgba(131, 58, 180, 1) 0%, rgba(202, 59, 99, 1) 12%, rgb(237 59 59) 18%, rgba(252, 176, 69, 1) 100%);
    border-radius: 19px;
    padding: 13px;
    cursor: pointer;
  }
  .btn-c:hover{
  background:rgb(237 85 59) 18%;
  }
</style>

<?php
include'../includes/connection.php';
include'../includes/sidebar.php';
?>
<?php 

                $query = 'SELECT id type FROM users 
                          WHERE id = '.$_SESSION['MEMBER_ID'].'';
                $result = mysqli_query($db, $query) or die (mysqli_error($db));
      
                while ($row = mysqli_fetch_assoc($result)) {
                          $Aa = $row['type'];
                   
if ($Aa=='User'){
           
             ?>    <script type="text/javascript">
                      //then it will be redirected
                      alert("Restricted Page! You will be redirected to POS");
                      window.location = "pos.php";
                  </script>
             <?php   }
                         
           
}

?>
<div class="row">
                <div class="col-lg-12">
                  <div class="card shadow mb-0">
                  <div class="card-header py-2">
                    <h4 class="m-1 text-lg text-primary"><button class="btn btn-primary" onclick="PrintFunction()"> <i class=" fas fa-solid fa-file"></i>Get your bill</button></h4>
                    <a class="btn btn-c text-white" id="emailMe" onClick="ShareLink()">Share with Gmail</a>
                  </div>
                        <!-- /.panel-heading -->
                        <div class="card-body" id="printing">
                        <img class="img-fluid billimg" src="billhead.jpg" alt="billheading">
                        <h3 class="text-info bg-light">Date:<?php $today = date('d/m/Y'); echo $today;?></h3>
                        <hr>
                        <?php
                        $findbill = $_GET['bill_id'];
                        //echo $findbill ;
                        if(isset($findbill)){
                        
                        	
                        		$sql = "SELECT * FROM billbook WHERE bill_id = '".$findbill."'";
                        		$data = mysqli_query($db,$sql)or die('error');
                        		if(mysqli_num_rows($data)>0){

                        			while($row = mysqli_fetch_assoc($data)){
                        				//print_r($row);
                        				// $bill_id = $row[0];
                                $custname = $row['custname'];
                                $custaddress = $row['custaddress'];
                                $custcontact= $row['custcontact'];
                                $model = $row['model'];
                                $machineslno = $row['machineslno'];
                                $maxcap = $row['maxcap'];
                                $mincap = $row['mincap'];
                                $eisd = $row['eisd'];
                                $class = $row['class'];
                                $brand = $row['brand'];
                                $govfees = $row['govfees'];
                                $otherdetails = $row['otherdetails'];
                                $qty = $row['qty'];
                                $rate = $row['rate'];
                                $amount = $row['amount'];
                                $additional = $row['additional'];
                                $grandtotal = $row['grandtotal'];
                        			}
                        		}
                        	
                        	}
                          else{
                              ?>
                               <h3 class="alert alert-warning text-dark">Bill not found</h3>
                               <?php
                          }           
                        ?>
                        <h2 class="text-info">Invoice number:# <?php echo $findbill; ?></h2>
                        <hr>
                        <div class="row">
                          <div class="col-lg-4">
                            <p class="text-warning">Customer Name:</p> <?php echo $custname; ?>
                          </div>
                          <div class="col-lg-4">
                            <p class="text-warning">Customer Address:</p><?php echo $custaddress; ?>
                          </div>
                          <div class="col-lg-4">
                            <p class="text-warning">Customer Contact:</p><?php echo $custcontact; ?>
                          </div>
                        </div>
                        <hr><h3 class="text-info">Machine Information</h3><br>
                        <hr><h4 class=" alert bg-danger text-white">Machine Verification / Reverification</h3><br>
                        <table id="billtable" class="table table-responsive col-lg-12">
                          <tr>
                            <th scope="col">Model</th>
                            <th scope="col">Machine slno</th>
                            <th scope="col">Max-capacity</th>
                            <th scope="col">Min-capacity</th>
                            <th scope="col">e=d</th>
                            <th scope="col">class</th>
                            <th scope="col">Brand</th>
                            <th scope="col">Govfees</th>
                          </tr>
                          <tr>
                            <td><?php echo $model; ?></td>
                            <td><?php echo $machineslno;?></td>
                            <td><?php echo $maxcap;?></td>
                            <td><?php echo $mincap;?></td>
                            <td><?php echo $eisd;?></td>
                            <td><?php echo $class;?></td>
                            <td><?php echo $brand;?></td>
                            <td><?php echo $govfees;?></td>
                          </tr>

                        </table>
                        
                          <hr><h4 class=" alert bg-info text-white">Other Details</h3><br>
                          <table class="table table-responsive col-lg-12">
                            <tr>
                          <th scope="col">Other details</th>
                            <th scope="col">Quantity</th>
                            <th scope="col">Rate</th>
                            <th scope="col">Amount</th>
                            <th scope="col">Additional</th>
                          </tr>
                          <tr>
                            <td><?php echo $otherdetails;?></td>
                            <td><?php echo $qty;?></td>
                            <td><?php echo $rate;?></td>
                            <td><?php echo $amount;?></td>
                            <td><?php echo $additional;?></td>
                          </tr>

                        </table>
                        <hr>
                          <tr><b>Grand total:₹<b><?php echo $grandtotal;?></tr><br>
                        <hr>
                        </div>
                       




<footer>
<?php
include'../includes/footer.php';
?>
</footer>
<script>
  function PrintFunction(){
    var prtContent = document.getElementById("printing");
   var imgwidth =  $('.billimg').width(917); // Units are assumed to be pixels
    var imgheight = $('.billimg').height(200);

    var WinPrint = window.open('', '', 'left=0,top=0,width=800,imgwidth,height=900,imgheight,toolbar=0,scrollbars=0,status=0');
    WinPrint.document.write(prtContent.innerHTML);
    WinPrint.document.title='jayguru Electronics E-bill System';
    WinPrint.document.close();
    WinPrint.focus();
    WinPrint.print();
    WinPrint.close();
  }
</script>
<script>
  function ShareLink()
  {
    let url = 'https://mail.google.com/mail/';

    window.open(url, 'sharer', 'toolbar=0,status=0,width=648,height=395');
  }

</script>