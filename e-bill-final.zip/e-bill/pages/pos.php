<?php
include'../includes/connection.php';
include'../includes/topp.php';
// session_start();

//session_destroy();

//check if Add to Cart button has been submitted
<?php include 'postabpane.php'; ?>
<!-- END TAB PANE AREA - ANG UNOD KA TABS ARA SA TABPANE.PHP -->

        <div style="clear:both"></div>  
        <br />  
        <div class="card shadow mb-4 col-md-12">
        <div class="card-header py-3 bg-white">
          <h4 class="m-2 font-weight-bold text-primary">Point of Sale</h4>
        </div>
        
      <div class="row">    
      <div class="card-body col-md-9">
        <div class="table-responsive">

        <!-- trial form lang   -->
<form role="form" method="post" action="pos_transac.php?action=add">
  <input type="hidden" name="employee" value="<?php echo $_SESSION['USER_NAME']; ?>">
  <input type="hidden" name="role" value="<?php echo $_SESSION['TYPE']; ?>">
  
       

<?php
include 'posside.php';
include'../includes/footer.php';
?>