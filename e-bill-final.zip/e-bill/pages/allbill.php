<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
<!--Data table CDN-->
      <!-- Datatable CSS -->
        <link href='DataTables/datatables.min.css' rel='stylesheet' type='text/css'>

        <!-- jQuery Library -->
        <script src="jquery-3.3.1.min.js"></script>
        
        <!-- Datatable JS -->
        <script src="DataTables/datatables.min.js"></script>
<!--Data table CDN-->
<!--Datatable button CDN-->
<script src="/assets/js/jquery-2.1.4.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/dataTables.buttons.min.js"></script> 
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script type="text/javascript" src="https://cdn.datatables.net/buttons/1.3.1/js/buttons.html5.min.js"></script>
<!--Datatable button CDN-->
<style type="text/css">
  .btn-c{
  background: linear-gradient(90deg, rgba(131, 58, 180, 1) 0%, rgba(202, 59, 99, 1) 12%, rgb(237 59 59) 18%, rgba(252, 176, 69, 1) 100%);
    border-radius: 19px;
    padding: 13px;
    cursor: pointer;
  }
  #regbtn:hover{
  background:rgb(237 85 59) 18%;
  }
</style>
<?php
//session_start();
include'../includes/connection.php';
include'../includes/sidebar.php';
?><?php 

                $query = 'SELECT id type FROM users 
                          WHERE id = '.$_SESSION['MEMBER_ID'].'';
                $result = mysqli_query($db, $query) or die (mysqli_error($db));
      
                while ($row = mysqli_fetch_assoc($result)) {
                          $Aa = $row['type'];
                   
if ($Aa=='User'){
           
             ?>    <script type="text/javascript">
                      //tden it will be redirected
                      alert("Restricted Page! You will be redirected to POS");
                      window.location = "pos.php";
                  </script>
             <?php   }
                         
           
}

?>
<?php

if(isset($_SESSION['status']))
    {
        ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <strong>Thank you</strong> <?= $_SESSION['status']; ?>
                <button type="button" class="btn-close btn btn-primary" data-dismiss="alert"
                 aria-label="Close">X</button>
            </div>
        <?php 
        unset($_SESSION['status']);
    }
?>
<div class="row">
                <div class="col-lg-12">
                  <div class="card shadow mb-0">
                  <div class="card-header py-2">
                    <h4 class="m-1 text-lg text-primary"><i class="fas fa-fw fa-table"></i> All Invoice</h4>
                  </div>
                        <!-- /.panel-heading -->
                        <div class="card-body">
                        <table id="BillShow" class="table table-responsive display dataTable" style="width:100%;">
                        	<thead class="bg-info text-white"style="width:100%;">
							             <tr>
                            
              							<td>Invoice no</td>	
              							<td>Customer Name</td>
              							<td>Customer Contact</td>
              							<td>Customer Address</td>
              							<td>Model</td>
                            <td>Machine slno</td>
                            <td>Max-capacity</td>
                            <td>Min-capacity</td>
                            <td>e=d</td>
                            <td>class</td>
                            <td>Brand</td>
                            <td>Govfees ₹</td>
                            <td>Other details</td>
                            <td>Quantity</td>
                            <td>Rate ₹</td>
                            <td>Amount ₹</td>
                            <td>Other Works</td>
                            <td>Quantity</td>
                            <td>Rate ₹</td>
                            <td>Amount ₹</td>
                            <td>Additional</td>
                            <td>Total Govt. fee ₹</td>
                            <td>Grand total ₹</td>
                            <td>Action</td>
                        	</tr>
                        	</thead>
                          </tbody>
                        </table>
                        </div>
                </div></table>
            </div>
</div>
<footer>
<?php
include'../includes/footer.php';
?>
</footer>
<script>
	$(document).ready(function(){
		//console.log("hi");
		$('#BillShow').DataTable({

			'processing': true,
      'serverSide': true,
      'dom':'lBfrtip',
        'buttons': [
                {
                    'extend': 'excelHtml5'
                }
            ],
      'serverMethod': 'post',
      'ajax': {
                    'url':'report.php'
          },
          'columns': [
                    { data: 'bill_id' },
                    { data: 'custname' },
                    { data: 'custcontact' },
                    { data: 'custaddress' },
                    { data: 'model' },
                    { data: 'machineslno' },
                    { data: 'maxcap' },
                    { data: 'mincap' },
                    { data: 'eisd' },
                    { data: 'class' },
                    { data: 'brand' },
                    { data: 'govfees' },
                    { data: 'otherdetails' },
                    { data: 'qty' },
                    { data: 'rate' },
                    { data: 'amount' },
                    {data: 'otherworks'},
                    {data: 'qty1'},
                    {data:'rate1'},
                    {data:'amount1'},
                    { data: 'additional' },
                    {data:'totalgovtfee'},
                    { data: 'grandtotal' },
                    { data: '',
                    render: (data,type,row) => {
                      return `<a id="view" class="btn btn-warning btn-sm "href='billview.php?billid=${row.bill_id}'><i class="fa fa-eye"></i></a>&nbsp;&nbsp; <a href="delete.php?billid=${row.bill_id}" id="delete" onclick="Delete()" class="btn btn-danger btn-sm "'><i class="fa fa-trash"></i></a>`;
                      }
                  }
                ]
		});

	});
</script>
<script>

  function Delete()
  {   

     let text = "Are you confirm to delete the data?";
   
      if (confirm(text) == true) {
          Redirect();
      } 
      else {
        alert("You are canceled the operation") ;
      }
     
}
function Redirect()
{
  window.location="delete.php";
}
</script>
