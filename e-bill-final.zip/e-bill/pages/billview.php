<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<style type="text/css">
  body {
  -webkit-print-color-adjust: exact !important;
}
.btn-c{
  background: linear-gradient(90deg, rgba(131, 58, 180, 1) 0%, rgba(202, 59, 99, 1) 12%, rgb(237 59 59) 18%, rgba(252, 176, 69, 1) 100%);
    border-radius: 19px;
    padding: 13px;
    cursor: pointer;
  }
  .btn-c:hover{
  background:rgb(237 85 59) 18%;
  }
  th, td {
  border: 1px solid black;
}

   .bgtable{
 background-image: url(weight.PNG);
    background-repeat: no-repeat;
    position-x: 15px;
    padding-top: 169px;
    margin-left: 596px;
    margin-top: -116px;
    opacity: 0.2;
}
/*.tabhr{
   border: 1px solid black;
}*/
.mysign {
    margin-top: -129px;
}
</style>
<?php
include'../includes/connection.php';
include'../includes/sidebar.php';
?>
<?php 

                $query = 'SELECT id type FROM users 
                          WHERE id = '.$_SESSION['MEMBER_ID'].'';
                $result = mysqli_query($db, $query) or die (mysqli_error($db));
      
                while ($row = mysqli_fetch_assoc($result)) {
                          $Aa = $row['type'];
                   
if ($Aa=='User'){
           
             ?>    <script type="text/javascript">
                      //then it will be redirected
                      alert("Restricted Page! You will be redirected to POS");
                      window.location = "pos.php";
                  </script>
             <?php   }
                         
           
}

?>
<div class="row">
                <div class="col-lg-12">
                  <div class="card shadow mb-0">
                  <div class="card-header py-2">
                    <h4 class="m-1 text-lg text-primary"><button class="btn btn-primary" onclick="PrintFunction()"> <i class=" fas fa-solid fa-file"></i>Get your bill</button></h4>
                    <a class="btn btn-c text-white" id="emailMe" onClick="ShareLink()">Share with Gmail</a>
                  </div>
                        <!-- /.panel-heading -->
                        <div class="card-body " id="printing">
                        <img class="img-fluid billimg" src="bill_head.jpg"alt="billheading">
                        <h4 align="right"class="text-info bg-light mytext">Date:<?php $today = date('d/m/Y'); echo $today;?></h4>
                        <hr>
                        <?php
                            // Check if billid parameter is set and not empty
                            if (isset($_GET['billid']) && !empty($_GET['billid'])) {
                                // Sanitize the input to prevent any security issues
                                $billid = htmlspecialchars($_GET['billid']);

                                // Now you can use $billid in your PHP code
                                //echo "The Invoice ID is: $billid"."Revised-invoice";
                            } else {
                                // Handle the case when billid is not provided in the URL
                                echo "Bill ID is missing.";
                            }
                          ?>
                          <?php
                          $findbill = $billid;
                          if(isset($findbill)){
                        
                          
                            $sql = "SELECT * FROM billbook WHERE bill_id = '".$findbill."'";
                            $data = mysqli_query($db,$sql)or die('error');
                            if(mysqli_num_rows($data)>0){

                              while($row = mysqli_fetch_assoc($data)){
                                //print_r($row);
                                // $bill_id = $row[0];
                                $custname = $row['custname'];
                                $custaddress = $row['custaddress'];
                                $custcontact= $row['custcontact'];
                                $model = $row['model'];
                                $machineslno = $row['machineslno'];
                                $maxcap = $row['maxcap'];
                                $mincap = $row['mincap'];
                                $eisd = $row['eisd'];
                                $class = $row['class'];
                                $brand = $row['brand'];
                                $govfees = $row['govfees'];
                                $totalgovfees = $row['totalgovtfee'];
                                $otherdetails = $row['otherdetails'];
                                $qty = $row['qty'];
                                $rate = $row['rate'];
                                $amount = $row['amount'];
                                $otherworks = $row['otherworks'];
                                $qty1 = $row['qty1'];
                                $rate1 = $row['rate1'];
                                $amount1 = $row['amount1'];
                                $additional = $row['additional'];
                                $grandtotal = $row['grandtotal'];
                                
                                $newmodel = explode(',', $model);
                                $newmachineslno = explode(',',$machineslno);
                                $newmaxcap =explode(',',$maxcap);
                                $newmincap = explode(',', $mincap);
                                $neweisd = explode(',',$eisd);
                                $newclass = explode(',',$class);
                                $newbrand = explode(',',$brand);
                                $newadditional = explode(',',$additional);
                                $newgovfees = explode(',',$govfees);
                                
                              }
                            }
                          
                          }
                          else{
                              ?>
                               <h3 class="alert alert-warning text-dark">Bill not found</h3>
                               <?php
                          }           
                        ?>
                        <h3 class="text-info mytext">Invoice number:# <?php echo $findbill; ?></h3>
                        <hr>
                          <h5 class="text-info mytext">Customer Details</h5>
                          <div class="row ">
                          <div class="col-lg-4">
                            <p class="text-warning myfont"><b>Customer Name:</b>&nbsp;<?php echo $custname; ?></p> 
                          </div>
                          <div class="col-lg-4">
                            <p class="text-warning myfont"><b>Customer Address:</b>&nbsp;<?php echo $custaddress; ?></p>
                          </div>
                          <div class="col-lg-4">
                            <p class="text-warning myfont"><b>Customer Contact:</b>&nbsp;<?php echo $custcontact; ?></p>
                          </div>
                        </div>
                        <hr><h4 class="text-info mytext">Machine Information
                          </h4>
                        <hr><h5 class=" alert bg-danger text-white veri">Machine Verification / Reverification</h5>

                        <table class="table table-responsive col-lg-12 table-stripped "id="mytable">
                          <tr>
                            <th class="mycolor">Model</th>
                            <th class="mycolor">Machine slno</th>
                            <th class="mycolor">Max-capacity</th>
                            <th class="mycolor">Min-capacity</th>
                            <th class="mycolor">e=d</th>
                            <th class="mycolor">class</th>
                            <th class="mycolor">Brand</th>
                            <th class="mycolor">Additional</th>
                            <th class="mycolor">Govt.fees</th>
                          </tr>
                          <tr id="row1">
                            <td class="mycolor"><?php 
                             foreach ($newmodel as $newmodel1) {

                                 echo $newmodel1."<hr class='tabhr'>";
                               }
                             ?>
                          </td>
                            <td class="mycolor"><?php
                             foreach ($newmachineslno as $newmachineslno1) {
                             echo $newmachineslno1."<hr class='tabhr'>";
                           }

                           ?>
                         </td>
                         <td class="mycolor"><?php
                             foreach ($newmaxcap as $newmaxcap1) {
                             echo $newmaxcap1."<hr class='tabhr'>";
                           }
                           ?>
                         </td>
                            <td class="mycolor"><?php
                             foreach ($newmincap as $newmincap1) {
                             echo $newmincap1."<hr class='tabhr'>";
                           }
                           ?>
                         </td>
                            <td class="mycolor"><?php
                             foreach ($neweisd as $neweisd1) {
                             echo $neweisd1."<hr class='tabhr'>";
                           }
                           ?>
                         </td>
                           <td class="mycolor"><?php
                             foreach ($newclass as $newclass1) {
                             echo $newclass1."<hr class='tabhr'>";
                           }
                           ?>
                         </td> 
                          <td class="mycolor"><?php
                             foreach ($newbrand as $newbrand1) {
                             echo $newbrand1."<hr class='tabhr'>";
                           }
                           ?>
                         </td> 
                         <td class="mycolor"><?php
                             foreach ($newadditional as $newadditional1) {
                             echo $newadditional1."<hr class='tabhr'>";
                           }
                           ?>
                         </td> 
                           <td class="mycolor"><?php
                             foreach ($newgovfees as $newgovfees1) {
                             echo $newgovfees1."<hr class='tabhr'>";
                           }
                           ?>
                         </td> 
                          
                          </tr>
                        </table>
                        <td><h5 align="right" class="bg-light light"><b>Total govt. fees:₹</b><?php echo $totalgovfees;?></h5></td>
                          <hr><h5 class=" alert bg-info text-white other">Other Details</h5>
                          <table class="table table-responsive col-lg-12">
                            <tr>
                                <th>Other details</th>
                                <th>Quantity</th>
                                <th>Rate</th>
                                <th>Amount</th>
                            
                          </tr>
                          <tr>
                            <td><?php echo $otherdetails;?></td>
                            <td><?php echo $qty;?></td>
                            <td><?php echo $rate;?></td>
                            <td><?php echo $amount;?></td>
                            
                          </tr>

                        </table>
                        
                        <hr>
                         <h3 class=" alert bg-primary text-white detail">Cleaning/Re-calibration/Fixing revate stamping plug/Testing/Service/Reparing/Other Works</h3>
                         <table class="table table-responsive col-lg-12">
                            <tr>
                          
                            
                            <th>Type of Service</th>
                            <th>Quantity</th>
                            <th>Rate ₹</th>
                            <th>Amount ₹</th>
                          </tr>
                          <tr>
                            <td><?php echo $otherworks;?></td>
                            <td><?php echo $qty1;?></td>
                            <td><?php echo $rate1;?></td>
                            <td><?php echo $amount1;?></td>
                            
                          </tr>

                        </table><hr>
                          <td><h4 align="right" class="bg-light light"><b>Grand total:₹<b><?php echo $grandtotal;?></h4></td><fieldset class="bgtable">Jay Guru Electronics</fieldset>
                        <hr>
                        <?php
                        $number = $grandtotal;
                         $no = floor($number);
                         $point = round($number - $no, 2) * 100;
                         $hundred = null;
                         $digits_1 = strlen($no);
                         $i = 0;
                         $str = array();
                         $words = array('0' => '', '1' => 'ONE', '2' => 'TWO',
                          '3' => 'THREE', '4' => 'FOUR', '5' => 'FIVE', '6' => 'SIX',
                          '7' => 'SEVEN', '8' => 'EIGHT', '9' => 'NINE',
                          '10' => 'TEN', '11' => 'ELEVEN', '12' => 'TWELVE',
                          '13' => 'THIRTEEN', '14' => 'FOURTEEN',
                          '15' => 'FIFTEEN', '16' => 'SIXTEEN', '17' => 'SEVENTEEN',
                          '18' => 'EIGHTEEN', '19' =>'NINETEEN', '20' => 'TWENTY',
                          '30' => 'THIRTY', '40' => 'FORTY', '50' => 'FIFTY',
                          '60' => 'SIXTY', '70' => 'SEVENTY',
                          '80' => 'EIGHTY', '90' => 'NINETY');
                         $digits = array('', 'HUNDRED', 'THOUSAND', 'LAKH', 'CRORE');
                         while ($i < $digits_1) {
                           $divider = ($i == 2) ? 10 : 100;
                           $number = floor($no % $divider);
                           $no = floor($no / $divider);
                           $i += ($divider == 10) ? 1 : 2;
                           if ($number) {
                              $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
                              $hundred = ($counter == 1 && $str[0]) ? ' AND ' : null;
                              $str [] = ($number < 21) ? $words[$number] .
                                  " " . $digits[$counter] . $plural . " " . $hundred
                                  :
                                  $words[floor($number / 10) * 10]
                                  . " " . $words[$number % 10] . " "
                                  . $digits[$counter] . $plural . " " . $hundred;
                           } else $str[] = null;
                        }
                        $str = array_reverse($str);
                        $result = implode('', $str);
                        $points = ($point) ?
                          "." . $words[$point / 10] . " " . 
                                $words[$point = $point % 10] : '';
                        echo "<p class='mysign'>Ruppes(in words):  ". $result ."Only/-</p>";
                        ?> <br>
                        <img class="img-fluid sign" align="right" src="sign.JPG" alt="Ashesh Biswas">
                        <p class="text-info mytext texti" align="right">For Jay Guru Electronics</p>
                        <h5 class="text-Danger nb" align="left">N.B.:- No Gurantee/Warantee on Reparing.</h5>
                        </div>

                       




<footer>
<?php
include'../includes/footer.php';
?>
</footer>
<script>
  function PrintFunction(){
    var prtContent = document.getElementById("printing");
   var imgwidth =  $('.billimg').width(917); // Units are assumed to be pixels
    var imgheight = $('.billimg').height(180);
    var sheight=$('.sign').height(98);
    var swidth=$('.sign').width(102);
    var WinPrint = window.open('', '', 'left=0,top=0,width=800,imgwidth,height=900,imgheight,sheight,swidth,toolbar=0,scrollbars=0,status=0');
    var htmlToPrint = '' +
        '<style type="text/css">' +
        ' th, table td {' +
        'border:1px solid black;' +
        'padding:0.5em;' +
        '}' +
        '.veri{'+
        'background:#E74A3B;'+
        'color: white;'+
        '}'+
        '.other{'+
        'background:#36B9CC;'+
        'color:white;}'+
        '.detail{'+
        'background:#4E73DF;'+
        'color:white;}'+
        '.mytext{color:#36B9CC;}'+
        '.nb{color:#E74A3B; margin-top:-97px;}'+
        'th{'+
        'background:#36B9CC;'+
        'color:white;}'+
        '.bgtable{'+
        'background-image: url(weight.PNG);'+
        ' background-repeat: repeat;'+
        'position-x: 15px;'+
        'padding-top: 160px;'+
        'margin-left: 3px;'+
        'margin-top: -156px;'+
        'opacity: 0.2;'+
        '}'+
        '.light{'+
        'background:#F8F9FC;'+
        '}'+
        '.mysign {'+
        ' margin-top: -125px;'+
        '}'+
        '.texti{'+
        'margin-top:-40px;'+
        '}'+
        '</style>';
    htmlToPrint += prtContent.outerHTML;
    WinPrint.document.write(htmlToPrint);
    WinPrint.document.title='jayguru Electronics E-bill System';
    WinPrint.document.close();
    WinPrint.focus();
    WinPrint.print();
    WinPrint.close();
  }
</script>
<script>
  function ShareLink()
  {
    let url = 'https://mail.google.com/mail/';

    window.open(url, 'sharer', 'toolbar=0,status=0,width=648,height=395');
  }

</script>
